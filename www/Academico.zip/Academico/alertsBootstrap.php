<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/jquery.min.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="alert alert-success">
            <strong>Success!</strong> Indicates a successful or positive action.
        </div>

        <div class="alert alert-info">
            <strong>Info!</strong> Indicates a neutral informative change or action.
        </div>

        <div class="alert alert-warning">
            <strong>Warning!</strong> Indicates a warning that might need attention.
        </div>

        <div class="alert alert-danger">
            <strong>Danger!</strong> Indicates a dangerous or potentially negative action.
        </div>
    </body>
</html>
