<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootsssstrap.min.js" type="text/javascript"></script>
    </head>
    <body>
        <h2>Contextual Backgrounds</h2>
        <p>Use the contextual background classes to provide "meaning through colors":</p>
        <p class="bg-primary">This text is important.</p>
        <p class="bg-success">This text indicates success.</p>
        <p class="bg-info">This text represents some information.</p>
        <p class="bg-warning">This text represents a warning.</p>
        <p class="bg-danger">This text represents danger.</p>

    </body>
</html>
