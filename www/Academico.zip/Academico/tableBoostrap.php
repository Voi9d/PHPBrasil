<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Table</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
    </head>
    <body>
        <table class="table table-bordered table-striped table-condensed">
            <thead>
                <tr>
                    <td>Nome</td>
                    <td>Sobrenome</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Miguel</td>
                    <td>Brasil</td>
                </tr>
                <tr>
                    <td>Maria</td>
                    <td>Joaquina</td>
                </tr>
            </tbody>
        </table>
        <img class="img-thumbnail img-responsive" src="img/campus-ufsm-gilciano-sala-2-.jpg" alt=""/>
    </body>
</html>
